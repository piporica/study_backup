const evenNumber = 100

if (evenNumber % 2 !== 0) {
  throw '오류'
}
